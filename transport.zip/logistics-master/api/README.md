## SpringBoot + Vue 的物流管理系统

#### 主要框架
- SpringBoot

- SpringData

- SpringSecurity

- Vue2