<template>
  <a-layout-footer :style="{ textAlign: 'center', letterSpacing: '1px' }">
    物流管理系统 ©2021 Created by 信息工程学院 - 高元明
  </a-layout-footer>
</template>

<script>
export default {
name: "Footer"
}
</script>

<style scoped>

</style>