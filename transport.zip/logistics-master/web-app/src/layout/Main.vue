<template>
  <a-layout-content :style="{ margin: '24px', overflow: 'initial' }">
    <router-view/>
  </a-layout-content>
</template>

<style scoped>

</style>