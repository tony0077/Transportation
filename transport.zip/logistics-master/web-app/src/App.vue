<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<style>

/*顶部进度条样式*/
#nprogress .bar {
  background: #1890ff !important;
}

body {
  letter-spacing: 1px;
  background: #f0f2f5 !important;
}

</style>